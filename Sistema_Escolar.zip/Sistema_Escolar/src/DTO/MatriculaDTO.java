package DTO;


public class MatriculaDTO {
    private String Nome,Apelido,Data,Sexo,Nome_pai,Nome_mae,Morada,Nacionalidade,Contanto, Classe;
    private int id_matricula;

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getApelido() {
        return Apelido;
    }

    public void setApelido(String Apelido) {
        this.Apelido = Apelido;
    }

    public String getData() {
        return Data;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public String getNome_pai() {
        return Nome_pai;
    }

    public void setNome_pai(String Nome_pai) {
        this.Nome_pai = Nome_pai;
    }

    public String getNome_mae() {
        return Nome_mae;
    }

    public void setNome_mae(String Nome_mae) {
        this.Nome_mae = Nome_mae;
    }

    public String getMorada() {
        return Morada;
    }

    public void setMorada(String Morada) {
        this.Morada = Morada;
    }

    public String getNacionalidade() {
        return Nacionalidade;
    }

    public void setNacionalidade(String Nacionalidade) {
        this.Nacionalidade = Nacionalidade;
    }

    public String getContanto() {
        return Contanto;
    }

    public void setContanto(String Contanto) {
        this.Contanto = Contanto;
    }

    public String getClasse() {
        return Classe;
    }

    public void setClasse(String Classe) {
        this.Classe = Classe;
    }

    public int getId_matricula() {
        return id_matricula;
    }

    public void setId_matricula(int id_matricula) {
        this.id_matricula = id_matricula;
    }
    
}
