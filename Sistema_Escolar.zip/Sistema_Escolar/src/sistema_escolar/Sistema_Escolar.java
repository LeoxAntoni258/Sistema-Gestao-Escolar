package sistema_escolar;

import VIEW.LoginVIEW;


public class Sistema_Escolar {


    public static void main(String[] args) {
        LoginVIEW login = new LoginVIEW();
        login.setVisible(true);

    }
    
}
