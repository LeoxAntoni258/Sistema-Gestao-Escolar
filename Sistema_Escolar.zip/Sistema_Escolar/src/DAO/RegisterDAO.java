
package DAO;

import DTO.RegisterDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;


public class RegisterDAO {

    public static boolean next() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    Connection conn;
    PreparedStatement pstm;
    //criando metodo
    public void cadastrarFuncionario(RegisterDTO objfuncionariodto){
        //identifando nomes da tabela e colunas e adcionando valor
        String sql = "insert into usuarios(nome,apelido,email,senha,senha_c) values(?,?,?,?,?)";
        
        conn = new ConexaoDAO().conectaBD();
        
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objfuncionariodto.getNome());
            pstm.setString(2, objfuncionariodto.getApelido());
            pstm.setString(3, objfuncionariodto.getEmail());
            pstm.setString(4, objfuncionariodto.getSenha());
            pstm.setString(5, objfuncionariodto.getSenha2());
            
            pstm.execute();
            pstm.close();
            
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "RegistarDao" + erro);
        }
    }
}
