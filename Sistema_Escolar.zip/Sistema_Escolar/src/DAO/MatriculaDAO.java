package DAO;

import DTO.MatriculaDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class MatriculaDAO {

    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<MatriculaDTO> lista = new ArrayList<>();

    public void Cadastrar(MatriculaDTO objmatriculadto) {

        String sql = "insert into aluno(nome,apelido,data_nascimento,sexo,nome_pai,nome_mae,morada,nacionalidade,contacto,classe) values(?,?,?,?,?,?,?,?,?,?)";

        conn = new ConexaoDAO().conectaBD();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objmatriculadto.getNome());
            pstm.setString(2, objmatriculadto.getApelido());
            pstm.setString(3, objmatriculadto.getData());
            pstm.setString(4, objmatriculadto.getSexo());
            pstm.setString(5, objmatriculadto.getNome_pai());
            pstm.setString(6, objmatriculadto.getNome_mae());
            pstm.setString(7, objmatriculadto.getMorada());
            pstm.setString(8, objmatriculadto.getNacionalidade());
            pstm.setString(9, objmatriculadto.getContanto());
            pstm.setString(10, objmatriculadto.getClasse());

            pstm.execute();
            pstm.close();

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "MatriculaDAO" + erro);
        }
    }

    public ArrayList<MatriculaDTO> PesquisarMatricula() {
        String sql = "select * from aluno";
        conn = new ConexaoDAO().conectaBD();

        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();

            while (rs.next()) {
                MatriculaDTO objmatriculaDTO = new MatriculaDTO();
                objmatriculaDTO.setId_matricula(rs.getInt("id"));
                objmatriculaDTO.setNome(rs.getString("nome"));
                objmatriculaDTO.setApelido(rs.getString("apelido"));
                objmatriculaDTO.setData(rs.getString("data_nascimento"));
                objmatriculaDTO.setSexo(rs.getString("sexo"));
                objmatriculaDTO.setNome_pai(rs.getString("nome_pai"));
                objmatriculaDTO.setNome_mae(rs.getString("nome_mae"));
                objmatriculaDTO.setMorada(rs.getString("morada"));
                objmatriculaDTO.setNacionalidade(rs.getString("nacionalidade"));
                objmatriculaDTO.setContanto(rs.getString("contacto"));
                objmatriculaDTO.setClasse(rs.getString("classe"));

                lista.add(objmatriculaDTO);

            }

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "MatriculaDAO Pesquisar" + erro);
        }
        return lista;
    }
    public void alterarMatricula(MatriculaDTO objmatriculadto){
        
        
        String sql = "update aluno set nome = ?, apelido = ?, data_nascimento = ?, sexo = ?, nome_pai = ?, nome_mae = ?,morada = ?,nacionalidade = ?,contacto = ?,classe = ? where id = ?";
        conn = new ConexaoDAO().conectaBD();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objmatriculadto.getNome());
            pstm.setString(2, objmatriculadto.getApelido());
            pstm.setString(3, objmatriculadto.getData());
            pstm.setString(4, objmatriculadto.getSexo());
            pstm.setString(5, objmatriculadto.getNome_pai());
            pstm.setString(6, objmatriculadto.getNome_mae());
            pstm.setString(7, objmatriculadto.getMorada());
            pstm.setString(8, objmatriculadto.getNacionalidade());
            pstm.setString(9, objmatriculadto.getContanto());
            pstm.setString(10, objmatriculadto.getClasse());
            pstm.setInt(11, objmatriculadto.getId_matricula());

            pstm.execute();
            pstm.close();

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "MatriculaDAO" + erro);
        }
        
    }
    

}
